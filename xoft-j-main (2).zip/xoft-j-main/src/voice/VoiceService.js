import { config } from '../config/index.js';

/**
 * VoiceService - server-side STT and TTS. Both are plain API calls, so the caller
 * (web or mobile client) only sends/receives audio bytes over HTTP.
 *
 * STT: OpenAI is primary and Gemini is the fallback (default order "openai,gemini").
 *      If the primary fails or returns no text, fallback starts immediately. If it is still
 *      running after STT_HEDGE_MS (default 1000), it is aborted and the next provider takes over.
 *      This prevents a late OpenAI response from overriding Gemini after the one-second cutoff.
 * TTS: ElevenLabs (flash model, small MP3). The browser client falls back to the device voice if this fails.
 *
 * Not here (needs a client with mic/speaker access): wake-word detection, VAD capture,
 * streaming playback, and the always-listening loop.
 */

const MAX_TTS_CHARS = 4000;
const GEMINI_AUDIO_MIME = {
  'audio/webm': 'audio/webm',
  'audio/ogg': 'audio/ogg',
  'audio/mp4': 'audio/mp4',
  'audio/m4a': 'audio/mp4',
  'audio/x-m4a': 'audio/mp4',
  'audio/mpeg': 'audio/mp3',
  'audio/mp3': 'audio/mp3',
  'audio/wav': 'audio/wav',
  'audio/x-wav': 'audio/wav',
};

function timeoutSignal(ms) {
  return AbortSignal.timeout(ms);
}

/** Timeout that can also be cancelled by the caller (used to drop the losing STT request). */
function withTimeout(ms, signal) {
  return signal ? AbortSignal.any([AbortSignal.timeout(ms), signal]) : AbortSignal.timeout(ms);
}

export class VoiceService {
  constructor({ fetchImpl = globalThis.fetch } = {}) {
    this.fetch = fetchImpl;
  }

  isTTSConfigured() {
    return Boolean(config.voice.elevenLabsApiKey);
  }

  /** Providers that are both in the configured order and have credentials. */
  sttProviders() {
    const available = {
      openai: Boolean(config.providers.openai.apiKey),
      gemini: Boolean(config.providers.gemini.apiKey),
    };
    // Keep the product contract deterministic: OpenAI first, Gemini second.
    // Do not let a stale environment/settings override reverse the required fallback order.
    return ['openai', 'gemini'].filter((name) => available[name]);
  }

  isSTTConfigured() {
    return this.sttProviders().length > 0;
  }

  status() {
    return {
      stt: { default: 'openai-gpt-transcribe', model: config.voice.sttOpenAiModel, providers: this.sttProviders(), configured: this.isSTTConfigured(), hedgeMs: config.voice.sttHedgeMs },
      tts: { provider: 'elevenlabs', configured: this.isTTSConfigured(), fallback: 'browser', streaming: true },
    };
  }

  async _ttsRequest(text) {
    if (!this.isTTSConfigured()) {
      throw new Error('VoiceService: ELEVENLABS_API_KEY is not set.');
    }
    const spoken = String(text ?? '').trim().slice(0, MAX_TTS_CHARS);
    if (!spoken) throw new Error('VoiceService: text is empty.');
    const format = config.voice.elevenLabsOutputFormat || 'mp3_22050_32';
    const res = await this.fetch(
      `https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(config.voice.elevenLabsVoiceId)}/stream?output_format=${encodeURIComponent(format)}`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'audio/mpeg',
          'xi-api-key': config.voice.elevenLabsApiKey,
        },
        body: JSON.stringify({
          text: spoken,
          model_id: config.voice.elevenLabsModel,
          voice_settings: { stability: 0.5, similarity_boost: 0.75 },
        }),
        signal: timeoutSignal(config.voice.ttsTimeoutMs),
      }
    );
    if (!res.ok) {
      const errText = await res.text().catch(() => '');
      throw new Error(`VoiceService: ElevenLabs API error ${res.status} - ${errText.slice(0, 300)}`);
    }
    return res;
  }

  /**
   * Streaming TTS: resolves as soon as ElevenLabs starts answering, so the caller can pipe the first audio
   * bytes to the client instead of waiting for the whole clip.
   * @param {string} text
   * @returns {Promise<{ body: ReadableStream<Uint8Array>|null, contentType: string }>}
   */
  async textToSpeechStream(text) {
    const res = await this._ttsRequest(text);
    return { body: res.body ?? null, contentType: 'audio/mpeg', response: res };
  }

  /**
   * @param {string} text
   * @returns {Promise<Buffer>} MP3 audio bytes
   */
  async textToSpeech(text) {
    const res = await this._ttsRequest(text);
    return Buffer.from(await res.arrayBuffer());
  }

  async _openaiTranscribe(audioBuffer, filename, signal, language = '') {
    const form = new FormData();
    form.append('file', new Blob([audioBuffer]), filename);
    const model = config.voice.sttOpenAiModel;
    form.append('model', model);
    form.append('response_format', 'json');
    if (config.voice.sttContextPrompt) form.append('prompt', config.voice.sttContextPrompt);
    // Whisper accepts temperature; newer transcription models may reject it.
    if (model === 'whisper-1') form.append('temperature', '0');
    // Leave language detection open for mixed Nigerian English/Pidgin/Igbo unless explicitly selected.
    const chosenLanguage = language === 'auto' ? '' : (language || config.voice.sttLanguage);
    if (chosenLanguage) form.append('language', chosenLanguage);
    const res = await this.fetch('https://api.openai.com/v1/audio/transcriptions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${config.providers.openai.apiKey}` },
      body: form,
      signal: withTimeout(config.voice.sttTimeoutMs, signal),
    });
    if (!res.ok) {
      const errText = await res.text().catch(() => '');
      throw new Error(`OpenAI transcription error ${res.status} - ${errText.slice(0, 300)}`);
    }
    const data = await res.json();
    return String(data?.text ?? '').trim();
  }

  async _geminiTranscribe(audioBuffer, mime, signal, language = 'auto') {
    const model = config.voice.sttGeminiModel || config.providers.gemini.model;
    const res = await this.fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': config.providers.gemini.apiKey },
        body: JSON.stringify({
          contents: [{
            role: 'user',
            parts: [
              { text: `${config.voice.sttContextPrompt} ${language === 'ig' ? 'The user selected Igbo; prioritize faithful Igbo transcription and preserve any English/Pidgin words that are spoken.' : language === 'en' ? 'The user selected English/Nigerian Pidgin; transcribe the spoken English or Pidgin verbatim and preserve any Igbo words that are spoken.' : 'Automatically detect the language. The audio may mix Nigerian English, Nigerian Pidgin and Igbo within the same sentence; preserve code-switching and do not translate.'} Reply with only the spoken words and nothing else. If there is no speech, reply with an empty string.` },
              { inline_data: { mime_type: GEMINI_AUDIO_MIME[mime] ?? 'audio/webm', data: Buffer.from(audioBuffer).toString('base64') } },
            ],
          }],
          generationConfig: { temperature: 0 },
        }),
        signal: withTimeout(config.voice.sttTimeoutMs, signal),
      }
    );
    if (!res.ok) {
      const errText = await res.text().catch(() => '');
      throw new Error(`Gemini transcription error ${res.status} - ${errText.slice(0, 300)}`);
    }
    const data = await res.json();
    const parts = data?.candidates?.[0]?.content?.parts ?? [];
    return parts.map((p) => p?.text ?? '').join('').trim();
  }

  /**
   * Transcribe with provider fallback and latency hedging.
   * @param {Buffer} audioBuffer
   * @param {{filename?: string, mime?: string}} [opts]
   * @returns {Promise<{text: string, provider: string, ms: number, attempts: Array<{provider: string, ok: boolean, error?: string, ms?: number}>}>}
   */
  async transcribe(audioBuffer, { filename = 'audio.webm', mime = 'audio/webm', language = null } = {}) {
    // Reject missing audio before making any billable provider request; never fabricate a transcript.
    if (!audioBuffer || !audioBuffer.length) {
      throw new Error('VoiceService: no audio was recorded; refusing to invent a transcript.');
    }
    const providers = this.sttProviders();
    if (!providers.length) {
      throw new Error('VoiceService: no speech-to-text provider configured. Set OPENAI_API_KEY (Whisper) and/or GEMINI_API_KEY.');
    }
    const startedAt = Date.now();
    const hedgeMs = config.voice.sttHedgeMs;
    const attempts = [];
    const controllers = new Map();

    return new Promise((resolve, reject) => {
      let nextIndex = 0;
      let pending = 0;
      let settled = false;
      let hedgeTimer = null;

      const sortedAttempts = () => [...attempts].sort((a, b) => providers.indexOf(a.provider) - providers.indexOf(b.provider));
      const clearHedge = () => { if (hedgeTimer) { clearTimeout(hedgeTimer); hedgeTimer = null; } };
      const armHedge = () => {
        clearHedge();
        if (settled || nextIndex >= providers.length || !(hedgeMs > 0)) return;
        hedgeTimer = setTimeout(() => {
          hedgeTimer = null;
          // Hard fail over at the configured cutoff: cancel the slow provider before starting the next.
          const slowProvider = providers[nextIndex - 1];
          controllers.get(slowProvider)?.abort(new Error(`STT provider exceeded ${hedgeMs}ms failover window`));
          startNext();
        }, hedgeMs);
      };

      const startNext = () => {
        if (settled || nextIndex >= providers.length) return;
        const provider = providers[nextIndex++];
        const controller = new AbortController();
        controllers.set(provider, controller);
        const t0 = Date.now();
        pending += 1;
        const requestedLanguage = ['auto', 'en', 'ig'].includes(language) ? language : null;
        const run = provider === 'openai'
          ? this._openaiTranscribe(audioBuffer, filename, controller.signal, requestedLanguage ?? '')
          : this._geminiTranscribe(audioBuffer, mime, controller.signal, requestedLanguage ?? 'auto');
        run.then((text) => ({ text, error: null }), (error) => ({ text: '', error })).then(({ text, error }) => {
          pending -= 1;
          if (settled) return; // lost the race; its request was aborted
          const ms = Date.now() - t0;
          if (text) {
            settled = true;
            clearHedge();
            attempts.push({ provider, ok: true, ms });
            for (const [name, c] of controllers) if (name !== provider) c.abort();
            resolve({ text, provider, ms: Date.now() - startedAt, attempts: sortedAttempts() });
            return;
          }
          attempts.push({ provider, ok: false, error: error ? error.message : 'empty transcript', ms });
          if (nextIndex < providers.length) startNext(); // failed or empty: do not wait for the hedge timer
          armHedge();
          if (pending === 0 && nextIndex >= providers.length) {
            settled = true;
            clearHedge();
            const list = sortedAttempts();
            const summary = list.map((a) => `${a.provider}: ${a.error}`).join('; ');
            const err = new Error(`VoiceService: speech-to-text failed (${summary}).`);
            err.attempts = list;
            reject(err);
          }
        });
      };

      startNext();
      armHedge();
    });
  }

  /** Back-compat: returns only the transcript string. */
  async speechToText(audioBuffer, filename = 'audio.webm', mime = 'audio/webm') {
    return (await this.transcribe(audioBuffer, { filename, mime })).text;
  }
}
